from mnist.trainer import MnistTrainer
